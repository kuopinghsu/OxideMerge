#!/bin/sh
set -eu
mkdir -p /opt/sample
cp -r lib /opt/sample
