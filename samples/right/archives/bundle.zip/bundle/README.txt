Sample bundle 1.1
Run ./install.sh to install.
