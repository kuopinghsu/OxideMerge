Sample bundle 1.0
Run ./install.sh to install.
