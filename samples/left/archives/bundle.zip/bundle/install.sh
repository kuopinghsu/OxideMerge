#!/bin/sh
set -e
cp -r lib /opt/sample
